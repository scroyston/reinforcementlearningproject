package rlframework;

public interface Action {

}
