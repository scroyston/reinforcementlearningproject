package rlframework;

public interface DiscreteState extends State {

}
