package rlframework;

public interface State {

}
