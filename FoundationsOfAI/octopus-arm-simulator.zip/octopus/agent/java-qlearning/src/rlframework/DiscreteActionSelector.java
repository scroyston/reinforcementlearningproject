package rlframework;

public interface DiscreteActionSelector {
    public DiscreteAction getAction(DiscreteState s);
}
