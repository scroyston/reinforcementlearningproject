package rlframework;

public interface StateDiscretizer {
    public DiscreteState discretize(State s);
}
