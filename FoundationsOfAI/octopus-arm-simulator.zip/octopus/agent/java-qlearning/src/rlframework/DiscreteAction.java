package rlframework;

public interface DiscreteAction extends Action {

}
